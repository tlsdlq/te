# Netlify Background Image Cache + Overlay

이 프로젝트는 외부 배경 이미지를 다운로드 후 캐싱하고, 요청마다 텍스트를 오버레이하여 WebP 형식으로 반환합니다.

## 기능
- 배경 이미지는 URL 해시를 기반으로 캐싱
- 텍스트 변경 시에도 배경 재사용
- 원본 비율 유지 리사이즈
- Markdown `![]()` 호출 가능

## 배포 방법
1. 이 폴더를 GitHub에 push
2. Netlify에 연결 후 배포
3. 호출 예시:
   ```
   https://<your-site>.netlify.app/.netlify/functions/overlay?bgImg=<배경URL>&text=Hello
   ```
