# Netlify Overlay (Background-only caching)

이 프로젝트는 **배경 이미지(bgImg)만 캐싱**하고, 요청마다 다른 텍스트는 그 위에 동적으로 오버레이하여 반환합니다.
- 배경 이미지는 최초 요청 시 다운로드 → WebP로 최적화 → 캐시(Blobs 또는 /tmp)에 저장됩니다.
- 이후 동일 bgImg 요청 시 배경은 캐시에서 읽고 텍스트만 오버레이하므로 재다운로드/재처리를 피합니다.
- 텍스트가 바뀌어도 **배경 캐시가 유효**하므로 배경 관련 네트워크/CPU 비용은 발생하지 않습니다.

엔드포인트 예시:
  /.netlify/functions/placeholder?bgImg=<url>&text=Hello%20World&format=webp

설치 및 배포:
1. npm install
2. git push to GitHub and connect to Netlify, or deploy via Netlify CLI.
3. (선택) @netlify/blobs를 사용하려면 Netlify 환경에서 활성화 후 사용하세요.

주의:
- Netlify Free 플랜의 함수 호출/대역폭/스토리지 한도를 초과하면 과금이나 제한이 발생할 수 있습니다.
- 외부 이미지는 신뢰할 수 없는 소스로부터 오므로 SSRF 보호 및 용량 제한이 포함되어 있습니다.
