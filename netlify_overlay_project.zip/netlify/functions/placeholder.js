const sharp = require('sharp');

function escapeXml(unsafe) {
  return unsafe.replace(/[&<>'"\\]/g, function (c) {
    switch (c) {
      case '&': return '&amp;';
      case '<': return '&lt;';
      case '>': return '&gt;';
      case "'": return '&apos;';
      case '"': return '&quot;';
      case '\\': return '';
    }
  });
}

exports.handler = async function(event) {
  const qs = event.queryStringParameters || {};
  const { bgImg, text = '', format = 'webp', bgColor, textColor, fontSize } = qs;

  if (!bgImg) return { statusCode: 400, body: 'bgImg required' };

  try {
    const siteUrl = process.env.URL || `https://${process.env.SITE_NAME || 'localhost'}`;
    const bgUrl = `${siteUrl}/.netlify/functions/optimized-bg?bgImg=${encodeURIComponent(bgImg)}`;

    const imageResponse = await fetch(bgUrl);
    if (!imageResponse.ok) throw new Error('Optimized BG fetch failed');

    const widthHeader = imageResponse.headers.get('x-image-width');
    const heightHeader = imageResponse.headers.get('x-image-height');
    const finalWidth = widthHeader ? parseInt(widthHeader, 10) : 600;
    const finalHeight = heightHeader ? parseInt(heightHeader, 10) : 400;

    const ab = await imageResponse.arrayBuffer();
    const bgBuf = Buffer.from(ab);

    // build SVG overlay
    const boxHeight = Math.floor(finalHeight * 0.25);
    const boxY = finalHeight - boxHeight;
    const fSize = fontSize ? parseInt(fontSize,10) : Math.floor(finalWidth / 28);
    const paddingX = Math.floor(finalWidth * 0.03);
    const textY = Math.floor(boxY + (boxHeight / 2));
    const safeText = escapeXml(text || '');

    const overlaySvg = `<svg width="${finalWidth}" height="${finalHeight}" xmlns="http://www.w3.org/2000/svg">
      <rect x="0" y="${boxY}" width="${finalWidth}" height="${boxHeight}" fill="${bgColor || 'rgba(0,0,0,0.5)'}"/>
      <text x="${paddingX}" y="${textY}" font-family="Arial, sans-serif" font-size="${fSize}" fill="${textColor || '#FFFFFF'}" dominant-baseline="middle">${safeText}</text>
    </svg>`;

    const overlayBuffer = Buffer.from(overlaySvg);

    // composite overlay onto background; output as requested format (webp/png)
    const outFormat = (format === 'png') ? 'png' : 'webp';
    const composed = await sharp(bgBuf)
      .composite([{ input: overlayBuffer, top: 0, left: 0 }])
      [outFormat]() // .webp() or .png()
      .toBuffer();

    const contentType = (outFormat === 'png') ? 'image/png' : 'image/webp';

    return {
      statusCode: 200,
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=3600, s-maxage=3600',
        'Netlify-Vary': 'query'
      },
      body: composed.toString('base64'),
      isBase64Encoded: true
    };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: 'Error generating image' };
  }
};
