const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function hashKey(s) {
  return crypto.createHash('sha256').update(s).digest('hex');
}

async function getTmpDir() {
  const base = process.env.TMPDIR || '/tmp';
  const dir = path.join(base, 'netlify-bg-cache');
  try { fs.mkdirSync(dir, { recursive: true }); } catch(e){}
  return dir;
}

function tmpPathForKey(key) {
  const dir = path.join(process.env.TMPDIR || '/tmp', 'netlify-bg-cache');
  const filename = path.join(dir, hashKey(key));
  return filename;
}

async function getCachedBufferTmp(key) {
  const filename = tmpPathForKey(key);
  try {
    if (fs.existsSync(filename)) {
      return fs.readFileSync(filename);
    }
  } catch(e){}
  return null;
}

async function setCachedBufferTmp(key, buffer) {
  const filename = tmpPathForKey(key);
  try {
    const dir = path.dirname(filename);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(filename, buffer);
    return true;
  } catch(e){
    console.warn('tmp cache write failed', e);
    return false;
  }
}

module.exports = { hashKey, getCachedBufferTmp, setCachedBufferTmp };
