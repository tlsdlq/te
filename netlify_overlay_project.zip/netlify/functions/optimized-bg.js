const sharp = require('sharp');
const { getCachedBufferTmp, setCachedBufferTmp, hashKey } = require('./cache-utils');

let blobStore = null;
try {
  const blobs = require('@netlify/blobs');
  if (blobs && typeof blobs.getStore === 'function') {
    blobStore = blobs.getStore && blobs.getStore('optimized-images');
  }
} catch (e) {
  blobStore = null;
}

async function tryGetFromBlobs(key) {
  if (!blobStore) return null;
  try {
    const data = await blobStore.get(key, { type: 'arrayBuffer' });
    if (data) return Buffer.from(data);
  } catch (e) {
    console.warn('blob get failed', e);
  }
  return null;
}

async function trySetToBlobs(key, buffer) {
  if (!blobStore) return false;
  try {
    await blobStore.set(key, buffer);
    return true;
  } catch (e) {
    console.warn('blob set failed', e);
    return false;
  }
}

exports.handler = async function(event) {
  const qs = event.queryStringParameters || {};
  const bgImg = qs.bgImg;
  if (!bgImg) return { statusCode: 400, body: 'bgImg required' };

  const cacheKey = hashKey(bgImg); // only bgImg used as key
  let optimizedBuffer = null;
  let width, height;

  // 1) try blobs
  optimizedBuffer = await tryGetFromBlobs(cacheKey);
  if (optimizedBuffer) {
    try {
      const meta = await blobStore.get(cacheKey + ':meta', { type: 'json' });
      if (meta) { width = meta.width; height = meta.height; }
    } catch (e) {}
  }

  // 2) tmp cache
  if (!optimizedBuffer) {
    const tmp = await getCachedBufferTmp(cacheKey);
    if (tmp) {
      optimizedBuffer = tmp;
      try {
        const metaTmp = await getCachedBufferTmp(cacheKey + ':meta');
        if (metaTmp) {
          const m = JSON.parse(metaTmp.toString());
          width = m.width; height = m.height;
        }
      } catch(e){}
    }
  }

  // 3) fetch and process
  if (!optimizedBuffer) {
    try {
      const siteUrl = process.env.URL || `https://${process.env.SITE_NAME || 'localhost'}`;
      const proxyUrl = `${siteUrl}/.netlify/functions/image-proxy?url=${encodeURIComponent(bgImg)}`;
      const resp = await fetch(proxyUrl);
      if (!resp.ok) throw new Error('proxy fetch failed ' + resp.status);
      const ab = await resp.arrayBuffer();
      const input = Buffer.from(ab);

      const img = sharp(input);
      const meta = await img.metadata();
      width = meta.width; height = meta.height;

      // convert to webp but keep original dimensions (no resizing)
      optimizedBuffer = await img.webp({ quality: 80 }).toBuffer();

      // persist to blobs and tmp
      trySetToBlobs(cacheKey, optimizedBuffer);
      try {
        setCachedBufferTmp(cacheKey, optimizedBuffer);
        setCachedBufferTmp(cacheKey + ':meta', Buffer.from(JSON.stringify({ width, height })));
      } catch(e){}
    } catch (err) {
      console.error('optimized-bg error', err);
      return { statusCode: 500, body: 'Error processing image.' };
    }
  }

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'image/webp',
      'Netlify-CDN-Cache-Control': 'public, max-age=31536000, durable',
      'Cache-Control': 'public, max-age=31536000, immutable',
      'X-Image-Width': width ? String(width) : '',
      'X-Image-Height': height ? String(height) : ''
    },
    body: optimizedBuffer.toString('base64'),
    isBase64Encoded: true
  };
};
