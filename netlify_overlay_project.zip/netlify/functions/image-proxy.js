exports.handler = async function(event) {
  const corsHeaders = { 'Access-Control-Allow-Origin': '*' };
  const qs = event.queryStringParameters || {};
  const { url } = qs;
  if (!url) {
    return { statusCode: 400, headers: corsHeaders, body: 'Missing url parameter' };
  }
  try {
    const decoded = decodeURIComponent(url);
    const res = await fetch(decoded);
    if (!res.ok) {
      return { statusCode: res.status, headers: corsHeaders, body: `Failed to fetch ${res.status}` };
    }
    const buf = await res.arrayBuffer();
    const contentType = res.headers.get('content-type') || 'application/octet-stream';
    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=31536000, s-maxage=31536000, immutable'
      },
      body: Buffer.from(buf).toString('base64'),
      isBase64Encoded: true
    };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, headers: corsHeaders, body: 'Proxy error' };
  }
};
